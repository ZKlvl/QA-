# Changelog

## 0.1 Beta

- Visual neuron canvas.
- Multiple maps.
- Nested sub-maps.
- Links between neurons.
- Review Mode.
- Markdown export.
- First-launch sample study map.
- Empty-board onboarding.

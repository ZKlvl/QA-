# Known Issues

- This is an early beta.
- No full undo/redo yet.
- No iCloud sync yet.
- No mobile app yet.
- Export is Markdown only for now.
- If the app was downloaded from the internet, macOS may require right-click -> Open on first launch.

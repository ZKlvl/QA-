# NeuronMap Beta

Thank you for trying NeuronMap.

NeuronMap is a private offline Mac app for visual study maps.

## Getting started

1. Open NeuronMap.
2. Explore the sample study map.
3. Create a new map from the left sidebar.
4. Press Command-N or click New Neuron to start.
5. Use Export Markdown when you want a portable copy.

## If macOS warns you

Right-click NeuronMap.app and choose Open the first time.

## Feedback

Please send feedback to: YOUR_EMAIL_HERE

The most helpful feedback:

- What was confusing?
- What felt useful?
- What would make this worth recommending?
- What feature would make this worth paying more for?

## Refunds

If NeuronMap does not help your study workflow, email within 14 days.
